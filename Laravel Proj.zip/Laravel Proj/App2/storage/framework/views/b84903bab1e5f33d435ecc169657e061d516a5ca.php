
<?php $__env->startSection('content'); ?>
<h1>Paradise Store</h1>
<hr/>
<div class="bg-dark text-white rounded p-3">
    <h2>Product <?php echo e($product->id); ?> :</h2>
    <h5 class="text-warning">Name :</h5>
    <p class="fw-bold"><?php echo e($product->name); ?></p>

    <h5 class="text-warning">Price :</h5>
    <p class="fw-bold"><?php echo e($product->price); ?> Dt</p>

    <h5 class="text-warning">Description :</h5>
    <p class="fw-bold"><?php echo e($product->description); ?></p>
</div>
<br/>
<p class="breadcrumb-item"><a href="<?php echo e(route('products.index')); ?>">Return</a></p>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\OBSIDIAN\Desktop\Laravel Proj\Laravel Proj\App2\resources\views/products/show.blade.php ENDPATH**/ ?>
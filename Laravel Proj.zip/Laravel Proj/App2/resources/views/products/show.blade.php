@extends('layouts.app')
@section('content')
<h1>Paradise Store</h1>
<hr/>
<div class="bg-dark text-white rounded p-3">
    <h2>Product {{$product->id}} :</h2>
    <h5 class="text-warning">Name :</h5>
    <p class="fw-bold">{{$product->name}}</p>

    <h5 class="text-warning">Price :</h5>
    <p class="fw-bold">{{$product->price}} Dt</p>

    <h5 class="text-warning">Description :</h5>
    <p class="fw-bold">{{$product->description}}</p>
</div>
<br/>
<p class="breadcrumb-item"><a href="{{route('products.index')}}">Return</a></p>
@endsection
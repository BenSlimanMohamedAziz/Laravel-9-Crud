
<?php $__env->startSection('content'); ?>
<h1>Paradise Store</h1>
<hr/>
<a class="btn btn-link float-end" href="<?php echo e(route('products.create')); ?>">Add New Product <i class="fa-solid fa-circle-plus"></i></a>

<?php if(session('success')): ?>
    <div class="alert alert-success">
        <?php echo e(session('success')); ?>

    </div>
<?php endif; ?>
<table class="table table-striped table-hover">
<thead>
    <tr></tr>
    <tr>
        <th scope="col">Product ID</th>
        <th scope="col">Product Name</th>
        <th scope="col">Product Price</th>
        <th scope="col">Action</th>
    </tr>
    </thead>  
    <tbody>
    <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>    
    <tr>
        <th scope="row"><?php echo e($loop->iteration); ?></th>
        <td><?php echo e($product->name); ?></td>
        <td><?php echo e($product->price); ?></td>
        <td>
            <div class="dropdown">
                <button class="btn btn-primary btn-sm dropdown-toggle" type="button" id="actionDropdown" data-mdb-toggle="dropdown" aria-expanded="false" style="letter-spacing: 2px;">Action</button>
            <ul class="dropdown-menu" aria-labelledby="axtionDropdown">
<li><a class="dropdown-item" href="<?php echo e(route('products.show',$product->id)); ?>">View &nbsp;<i class="fa-solid fa-eye"></i></a></li>
<li><a class="dropdown-item" href="<?php echo e(route('products.edit',$product->id)); ?>">Edit &nbsp;<i class="fa-solid fa-pen-to-square"></i></a></li>           
<li>
    <form action="<?php echo e(route('products.destroy',$product->id)); ?>" method="POST">
    <?php echo csrf_field(); ?>
    <?php echo method_field('delete'); ?>
    <button type="submit" class="dropdown-item">Delete &nbsp;<i class="fa-solid fa-trash"></i></button>
    </form>
</li>
</ul>
            </div>
        </td>
    </tr>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </tbody>  
</table>    

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\AZIZ\DSI22\Laravel Projects\App 2\Crud Store\resources\views/products/index.blade.php ENDPATH**/ ?>
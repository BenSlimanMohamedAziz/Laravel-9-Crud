
<?php $__env->startSection('content'); ?>
<h1>Paradise Store</h1>
<br/>
<h6>Add New Product</h6>
<hr/>

<?php if($errors->any()): ?>
<div class="alert alert-danger">
    <ul>
        <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <li><?php echo e($error); ?></li>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </ul>
</div>
<?php endif; ?>
<form action="<?php echo e(route('products.store')); ?>" method="post">
    <?php echo csrf_field(); ?>
    <input type="text" name="name" class="form-control mb-3" placeholder="Product Name">
    <input type="number" name="price" class="form-control mb-3" placeholder="Price $$">
    <textarea class="form-control mb-3" name="description" rows="4" placeholder="Description"></textarea>
    <button class="btn btn-primary float-end px-5" type="submit">Submit</button>
    </form>
    <?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\OBSIDIAN\Desktop\Laravel Proj\Laravel Proj\App2\resources\views/products/create.blade.php ENDPATH**/ ?>
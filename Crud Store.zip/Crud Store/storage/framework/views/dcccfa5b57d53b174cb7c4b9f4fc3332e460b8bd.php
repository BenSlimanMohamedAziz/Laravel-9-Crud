
<?php $__env->startSection('content'); ?>
<h1>Paradise Store</h1>
<br/>
<h6>Edit Product &nbsp;<i class="fa-solid fa-pen-to-square"></i></h6>
<hr/>

<?php if($errors->any()): ?>
<div class="alert alert-danger">
    <ul>
        <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <li><?php echo e($error); ?></li>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </ul>
</div>
<?php endif; ?>
<form action="<?php echo e(route('products.update',$product->id)); ?>" method="post">
<?php echo csrf_field(); ?>
<?php echo method_field('put'); ?>
<input type="text" name="name" class="form-control mb-3" placeholder="Product Name" value="<?php echo e($product->name); ?>">
<input type="number" name="price" class="form-control mb-3" placeholder="Price $$" value="<?php echo e($product->price); ?>">
<textarea class="form-control mb-3" name="description" rows="4" placeholder="Description"><?php echo e($product->description); ?></textarea>
<button class="btn btn-primary float-end px-5" type="submit" style="letter-spacing: 2px;">Edit</button>
<p class="breadcrumb-item"><a class="float-start" href="<?php echo e(route('products.index')); ?>"><i class="fa-solid fa-chevron-left"></i> Return</a></p>
</form>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\AZIZ\DSI22\Laravel Projects\App 2\Crud Store\resources\views/products/edit.blade.php ENDPATH**/ ?>
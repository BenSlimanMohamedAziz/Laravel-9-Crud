@extends('layouts.app')
@section('content')
<h1>Paradise Store</h1>
<hr/>
<a class="btn btn-link float-end" href="{{route('products.create')}}">Add New Product <i class="fa-solid fa-circle-plus"></i></a>
{{-- Display message --}}
@if (session('success'))
    <div class="alert alert-success">
        {{session('success')}}
    </div>
@endif
<table class="table table-striped table-hover">
<thead>
    <tr></tr>
    <tr>
        <th scope="col">Product ID</th>
        <th scope="col">Product Name</th>
        <th scope="col">Product Price</th>
        <th scope="col">Action</th>
    </tr>
    </thead>  
    <tbody>
    @foreach($products as $product)    
    <tr>
        <th scope="row">{{$loop->iteration}}</th>
        <td>{{$product->name}}</td>
        <td>{{$product->price}}</td>
        <td>
            <div class="dropdown">
                <button class="btn btn-primary btn-sm dropdown-toggle" type="button" id="actionDropdown" data-mdb-toggle="dropdown" aria-expanded="false" style="letter-spacing: 2px;">Action</button>
            <ul class="dropdown-menu" aria-labelledby="axtionDropdown">
<li><a class="dropdown-item" href="{{route('products.show',$product->id)}}">View &nbsp;<i class="fa-solid fa-eye"></i></a></li>
<li><a class="dropdown-item" href="{{route('products.edit',$product->id)}}">Edit &nbsp;<i class="fa-solid fa-pen-to-square"></i></a></li>           
<li>
    <form action="{{route('products.destroy',$product->id)}}" method="POST">
    @csrf
    @method('delete')
    <button type="submit" class="dropdown-item">Delete &nbsp;<i class="fa-solid fa-trash"></i></button>
    </form>
</li>
</ul>
            </div>
        </td>
    </tr>
    @endforeach
    </tbody>  
</table>    

@endsection